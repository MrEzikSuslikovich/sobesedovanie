<?php
	require "functions.php";
	require "style.css";
?>